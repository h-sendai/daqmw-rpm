---
name: Question
about: Questions about this project (Note! This is C++ repository)
title: ''
labels: question
assignees: ''

---


<!--
***********************************************************************
*                           << NOTE >>                                *
*  This repository have been programmed in C++.                       *
*                                                                     *
*  Please do not create tickets for other programming languages here. *
*  If you will create tickets for other programming language,         *
*  please see below:                                                  *
*                                                                     *
*  - Python : https://github.com/OpenRTM/OpenRTM-aist-Python/issues   *
*  - Java   : https://github.com/OpenRTM/OpenRTM-aist-Java/issues     *
*                                                                     *
***********************************************************************
-->

